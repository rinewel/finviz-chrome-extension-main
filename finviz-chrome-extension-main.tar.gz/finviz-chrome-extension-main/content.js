// =========================================================
// 1. HELPER: Extract tickers from the table
// =========================================================
function extractTickersFromDocument(doc) {
  // Find the table that has a "Ticker" header
  const tables = Array.from(doc.querySelectorAll("table"));
  let targetTable = null;
  let tickerColIndex = -1;

  for (const table of tables) {
    const headerRows = [
      ...table.querySelectorAll("thead tr"),
      ...table.querySelectorAll("tr")
    ].slice(0, 3);

    for (const tr of headerRows) {
      const ths = Array.from(tr.querySelectorAll("th"));
      if (!ths.length) continue;
      const idx = ths.findIndex(th => th.textContent.trim().toLowerCase() === "ticker");
      if (idx !== -1) {
        targetTable = table;
        tickerColIndex = idx;
        break;
      }
    }
    if (targetTable) break;
  }

  if (!targetTable || tickerColIndex === -1) return [];

  const rows = Array.from(targetTable.querySelectorAll("tbody tr, tr"));
  const out = [];
  for (const tr of rows) {
    if (tr.querySelector("th")) continue;
    const tds = Array.from(tr.querySelectorAll("td"));
    if (tds.length <= tickerColIndex) continue;
    const cell = tds[tickerColIndex];
    const a = cell.querySelector("a");
    const raw = (a ? a.textContent : cell.textContent).trim();
    if (raw && /^[A-Z0-9.\-]+$/.test(raw)) out.push(raw);
  }
  return out;
}

// =========================================================
// 2. HELPER: Parse Page Count (Fallback)
// =========================================================
function parseTotalPages(doc) {
  const m = doc.body.innerText.match(/Page\s+(\d+)\s*\/\s*(\d+)/i);
  if (m) return { current: parseInt(m[1], 10), total: parseInt(m[2], 10) };
  return { current: 1, total: 1 };
}

// =========================================================
// 3. HELPER: Parse Total Rows (Robust)
// =========================================================
function parseTotalRows(doc) {
  const text = doc.body.innerText;
  // Matches "Total: 10,449" OR "#1 / 10,449 Total" OR "10449 Total"
  const m = text.match(/(?:Total:|#\s*\d+\s*\/)\s*([\d,]+)|([\d,]+)\s*Total/i);
  
  if (m) {
    const numStr = m[1] || m[2];
    return parseInt(numStr.replace(/,/g, ""), 10);
  }
  return null;
}

// =========================================================
// 4. HELPER: Generate URL (Preserves Filters)
// =========================================================
function pageUrlFor(baseHref, perPage, pageNum) {
  // Use the current window's URL parameters to ensure we don't lose filters
  const currentParams = new URLSearchParams(window.location.search);
  
  // Calculate start row (Finviz uses 'r' for the starting record index)
  const start = 1 + perPage * (pageNum - 1);
  currentParams.set("r", String(start));
  
  const u = new URL(baseHref);
  u.search = currentParams.toString();
  return u.toString();
}

// =========================================================
// 5. HELPER: Fetch via Iframe (Bypasses Bot Check)
// =========================================================
async function fetchDoc(url) {
  return new Promise((resolve, reject) => {
    const iframe = document.createElement("iframe");
    
    // Hide the iframe completely
    iframe.style.cssText = "position:absolute; width:0; height:0; border:0; visibility:hidden; z-index:-9999;";
    iframe.src = url;

    // Set a safety timeout (e.g., 10 seconds)
    const timeoutId = setTimeout(() => {
        if(iframe.parentNode) document.body.removeChild(iframe);
        reject(new Error("Timeout loading page via iframe"));
    }, 10000);

    iframe.onload = () => {
      clearTimeout(timeoutId);
      try {
        // Access the content of the iframe
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        
        // Clone the HTML so we can parse it
        const html = iframeDoc.documentElement.outerHTML;
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, "text/html");
        
        // Cleanup: Remove iframe
        document.body.removeChild(iframe);
        resolve(doc);
      } catch (e) {
        if(iframe.parentNode) document.body.removeChild(iframe);
        reject(e);
      }
    };

    iframe.onerror = (e) => {
      clearTimeout(timeoutId);
      if(iframe.parentNode) document.body.removeChild(iframe);
      reject(new Error("Iframe failed to load"));
    };

    document.body.appendChild(iframe);
  });
}

// =========================================================
// 6. MAIN LISTENER
// =========================================================
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "GET_TICKERS") return;

  (async () => {
    try {
      const doc = document;
      const firstPageTickers = extractTickersFromDocument(doc);
      
      if (firstPageTickers.length === 0) {
        sendResponse({ tickers: [], error: "No tickers found on current page." });
        return;
      }

      const perPage = firstPageTickers.length; 
      const totalRows = parseTotalRows(doc);
      
      // Calculate total pages
      let pages = 1;
      if (totalRows) {
        pages = Math.ceil(totalRows / perPage);
      } else {
        const p = parseTotalPages(doc);
        pages = p.total;
      }

      console.log(`[Ticker Fetcher] Found ${totalRows || 'unknown'} total rows. Pages: ${pages}`);

      // If user requested only the current page
      if (!msg.allPages) {
        const unique = [...new Set(firstPageTickers)];
        sendResponse({ tickers: unique, pages: 1, perPage, totalRows, error: null });
        return;
      }

      const seen = new Set(firstPageTickers);
      const all = [...firstPageTickers];
      const baseHref = location.href;

      // Loop through remaining pages
      for (let p = 2; p <= pages; p++) {
        console.log(`[Ticker Fetcher] Processing page ${p} of ${pages}...`);
        
        const url = pageUrlFor(baseHref, perPage, p);
        
        // Use the Iframe fetcher
        const d = await fetchDoc(url);
        const tickers = extractTickersFromDocument(d);
        
        if (tickers.length === 0) {
           console.warn(`[Ticker Fetcher] Page ${p} returned 0 tickers. Stopping safely.`);
           // Send partial results instead of failing completely
           sendResponse({
             tickers: all,
             pages,
             perPage,
             totalRows,
             error: `Stopped at page ${p} (Empty response)`
           });
           return;
        }

        for (const t of tickers) {
          if (!seen.has(t)) {
            seen.add(t);
            all.push(t);
          }
        }
        
        // DELAY: 2.5 seconds to be polite and ensure the Iframe renders fully
        await new Promise(r => setTimeout(r, 2500));
      }

      sendResponse({
        tickers: all,
        pages,
        perPage,
        totalRows,
        error: null
      });

    } catch (e) {
      console.error("[Ticker Fetcher] Error:", e);
      sendResponse({ tickers: [], error: e?.message || "Failed to fetch pages." });
    }
  })();

  return true; // Keep channel open
});