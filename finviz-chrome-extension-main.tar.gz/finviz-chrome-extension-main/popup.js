const $ = s => document.querySelector(s);

const formatText = (tickers, mode) => {
  switch (mode) {
    case "twitter":
      // Prefix each with $ and join by single spaces
      return tickers.map(t => `$${t}`).join(" ");
    case "newline":
      return tickers.join("\n");
    case "comma":
    default:
      return tickers.join(",");
  }
};

// Parse whatever's currently in the textarea back to a clean ticker list
const parseText = (text) => {
  return text
    .replace(/\$/g, "")                  // strip $ if pasted from Twitter
    .split(/[\s,\n]+/)                   // split on spaces, commas, or newlines
    .map(s => s.trim().toUpperCase())
    .filter(Boolean);
};

function updateTweetMeter() {
  const isTwitter = $("#format").value === "twitter";
  const meter = $("#tweet-meter");
  if (!isTwitter) {
    meter.style.display = "none";
    return;
  }
  meter.style.display = "block";
  const len = $("#output").value.length;
  $("#tweet-chars").textContent = len;
  $("#tweet-chars").style.color = len <= 280 ? "#2b7a0b" : "#c00";
}

function sendGetTickers({ allPages }) {
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      const tab = tabs[0];
      if (!tab?.id) return resolve({ tickers: [], error: "No active tab." });

      chrome.tabs.sendMessage(tab.id, { type: "GET_TICKERS", allPages }, resp => {
        if (chrome.runtime.lastError) {
          resolve({ tickers: [], error: "Not on a Finviz page (or it hasn't loaded)." });
        } else {
          resolve(resp || { tickers: [], error: "No response from page." });
        }
      });
    });
  });
}

$("#fetch").addEventListener("click", async () => {
  $("#status").textContent = "Fetching…";
  $("#output").value = "";

  const allPages = $("#scope").value === "all";
  const { tickers, error, pages, perPage, totalRows } = await sendGetTickers({ allPages });

  if (error) {
    $("#status").textContent = error;
    updateTweetMeter();
    return;
  }

  const mode = $("#format").value;
  $("#output").value = formatText(tickers, mode);

  let meta = `Found ${tickers.length} tickers`;
  if (allPages && pages) meta += ` across ${pages} page(s)`;
  if (perPage) meta += ` (~${perPage}/page)`;
  if (totalRows) meta += ` of ~${totalRows} total rows`;
  $("#status").textContent = meta + ".";
  updateTweetMeter();
});

$("#format").addEventListener("change", () => {
  // Reformat current output without re-fetching
  const current = $("#output").value.trim();
  if (!current) {
    updateTweetMeter();
    return;
  }
  const tickers = parseText(current);
  $("#output").value = formatText(tickers, $("#format").value);
  updateTweetMeter();
});

$("#output").addEventListener("input", updateTweetMeter);

$("#copy").addEventListener("click", async () => {
  const text = $("#output").value.trim();
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    $("#status").textContent = "Copied to clipboard.";
  } catch {
    $("#status").textContent = "Copy failed. Select and copy manually.";
  }
  updateTweetMeter();
});

$("#download").addEventListener("click", () => {
  const text = $("#output").value.trim();
  if (!text) return;
  const blob = new Blob([text + "\n"], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({ url, filename: "finviz_tickers.txt", saveAs: true });
});
